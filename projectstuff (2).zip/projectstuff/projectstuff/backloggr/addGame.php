<?php

session_start();

if(isset($_SESSION['myUserID']))
{

} else {
  header('location: index.php');
}

include("conn.php");
$getid = $conn->real_escape_string($_GET['game']);

  $read = "SELECT * FROM LB_Games WHERE id = '$getid'";
  $result = $conn->query($read);

  $_SESSION['currentGame'] = $getid;

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Page Title -->
  <title>BackLoggr</title>

	<!-- Compiled and minified CSS -->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link href="style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

	<!-- Compiled and minified JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

	<script>
	   $(function(){
      $(".dropdown-trigger").dropdown();
			$('.tooltipped').tooltip();
	   });
	</script>

<body>
  <div class="navbar-fixed">
    <nav role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="index.php" class="brand-logo left"><i class="material-icons">videogame_asset</i>BackLoggr</a>
       <ul id="nav-mobile" class="right">
         <?php
         if(isset($_SESSION['myusername']))
         {
           echo "<li><a href='user.php'>My Profile</a></li>";
         } else {
         }
          ?>
        <li><form>
       </form></li>
      </ul>
    </div>
  </nav>
 </div>

 <?php
   while($row = $result->fetch_assoc() ){

     $title_data = $row['title'];

    echo "<div id='index-banner' class='container'>
      <div class='section no-pad-bot'>
        <div class='container'>
          <h1 class='header center blue-text text-lighten-2'>Reviewing $title_data</h1>
        </div>
      </div>
    </div>

    ";
}
?>
    <form action='reviewAdder.php' method='post' enctype='multipart/form-data'>
    <div class='container'>
    <div class='row'>
      <div class='col s2'>
        &nbsp
      </div>
      <div class='col s8 input-field'>
        <select class='browser-default' name='Rating' required>
          <option value='' disabled selected>Choose a score for the review!</option>
          <option value='1'>1</option>
          <option value='2'>2</option>
          <option value='3'>3</option>
          <option value='4'>4</option>
          <option value='5'>5</option>
          <option value='6'>6</option>
          <option value='7'>7</option>
          <option value='8'>8</option>
          <option value='9'>9</option>
          <option value='10'>10</option>
        </select>
      </div>
      <div class='col s2'>
        &nbsp
      </div>
    </div>

    <div class='row'>
      <div class='col s2'>
        &nbsp
      </div>
      <div class='col s8 signin'>
        <label for='Heading'><b>Heading</b></label>
        <input type='text' placeholder='Please enter a heading for your review here!' name='Heading' maxlength="200" required>
      </div>
      <div class='col s2'>
        &nbsp
      </div>
    </div>

    <div class='row'>
      <div class='col s2'>
        &nbsp
      </div>
      <div class='col s8 signin'>
        <label for='Review'><b>Review</b></label>
        <textarea rows = '10' cols = '60' name = 'Review' required></textarea>
      </div>
      <div class='col s2'>
        &nbsp
      </div>
    </div>

    <div class='row'>
      <div class='col s5'>
        &nbsp
      </div>
      <div class='col s2'>
        <button class='btn waves-effect waves-light blue lighten-1' type='submit' name='submit'>Submit</button>
      </div>
      <div class='col s5'>
        &nbsp
      </div>
    </div>

    </div>
    </form>

</body>

</html>

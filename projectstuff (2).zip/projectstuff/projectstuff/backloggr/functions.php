<?php

/**
* Declaring Vars
**/
$lengthOfSalt = 32;
/**
* Checks whether or not the username already exists in the database
*/
function userExists($username){
	$query = "SELECT Username FROM LB_Users WHERE Username = ?";
	global $conn;
	if($stmt = $conn->prepare($query)){
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$stmt->store_result();
		$stmt->fetch();
		if($stmt->num_rows == 1){
			$stmt->close();
			return true;
		}
		$stmt->close();
	}

	return false;
}

/**
* Generates a new unique Salt
*/
function getSalt(){
	global $lengthOfSalt;
	return bin2hex(openssl_random_pseudo_bytes($lengthOfSalt));
}

/**
* Creates a new Password salt through concatenation of the Password and Salt
*/
function concatPasswordWithSalt($password,$salt){
	global $lengthOfSalt;
	if($lengthOfSalt % 2 == 0){
		$mid = $lengthOfSalt / 2;
	}
	else{
		$mid = ($lengthOfSalt - 1) / 2;
	}

	return
	substr($salt,0,$mid - 1).$password.substr($salt,$mid,$lengthOfSalt - 1);

}
?>

<?php

  session_start();

  if(isset($_SESSION['myUserID']))
  {

  } else {
    header('location: index.php');
  }

  include("conn.php");



  if(isset($_SESSION['mysearch']))
  {
    $row = $_SESSION['mysearch'];
    $result = $conn->query($row);
    unset($_SESSION['mysearch']);
  } else {
    $read = "SELECT * FROM LB_Games";
    $result = $conn->query($read);
  }

  if(!$result) {
    echo $conn->error;
  }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Page Title -->
  <title>BackLoggr</title>

	<!-- Compiled and minified CSS -->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link href="style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

	<!-- Compiled and minified JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

	<script>
	   $(function(){
      $(".dropdown-trigger").dropdown();
			$('.tooltipped').tooltip();
	   });
	</script>

<body>
  <div class="navbar-fixed">
    <nav role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="index.php" class="brand-logo left"><i class="material-icons">videogame_asset</i>BackLoggr</a>
       <ul id="nav-mobile" class="right">
         <?php
         if(isset($_SESSION['myusername']))
         {
           echo "<li><a href='user.php'>My Profile</a></li>";
         } else {
         }
          ?>
        <li><form>
       </form></li>
      </ul>
    </div>
  </nav>
 </div>

 <!--
   <form action='search.php' method='post' enctype='multipart/form-data'>
   <div id=searchBarUser class='container'>
   <div class='row'>
     <div class='col s10 signin'>
       <label for='query'><b>Search for a game to review.</b></label>
       <input type='text' placeholder='Search for a Game' name='query' required>
     </div>
     <div class='col s2'>
       <button class='btn waves-effect waves-light blue lighten-1' type='submit' name='submit'>Submit</button>
     </div>
   </div>
 </div>
 </form>
   -->

  <div id="itemList" class="container">
   	<?php

  		while($row = $result->fetch_assoc() ){

        $title_data = $row['title'];
        $dev_data = $row['developer'];
        $year_data = $row['release_year'];
        $desc_data= $row['description'];
        $game_id = $row['id'];
        $image_data = $row['cover_art'];


  			echo "<div class='row cus'>

              <div class='col s2'>
                <img id='itemImage' src='$image_data' alt='' class='responsive-img'>
              </div>

  						<div class='col s8'>
  							<h5>$title_data</h5>
                <span class='black-text'>
                <h6>$dev_data</h6>

                <br><h6>$desc_data</h6>
  							 <br>$year_data
                 </span>
  						</div>

  						<div class='col s2'>
              <br>
              <br>
              <br>
  							<a href='addGame.php?game=$game_id' class='btn-large waves-effect waves-light blue lighten-1'>Review</a>
  						</div>

  					</div>

  				<div class='divider'></div>";
  		}

  	?>

  </div>

  </body>

  </html>

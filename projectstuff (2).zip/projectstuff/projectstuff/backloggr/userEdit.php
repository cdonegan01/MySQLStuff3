<?php

  session_start();

  if(isset($_SESSION['myUserID']))
  {

  } else {
    header('location: index.php');
  }

  include("conn.php");

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Page Title -->
  <title>BackLoggr</title>

	<!-- Compiled and minified CSS -->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link href="style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

	<!-- Compiled and minified JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

	<script>
	   $(function(){
      $(".dropdown-trigger").dropdown();
			$('.tooltipped').tooltip();
	   });
	</script>

<body>
  <div class="navbar-fixed">
    <nav role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="index.php" class="brand-logo left"><i class="material-icons">videogame_asset</i>BackLoggr</a>
       <ul id="nav-mobile" class="right">
         <?php
         if(isset($_SESSION['myusername']))
         {
           echo "<li><a href='user.php'>My Profile</a></li>";
         } else {
         }
          ?>
        <li><form>
       </form></li>
      </ul>
    </div>
  </nav>
 </div>

  <?php
    echo "<form action='userEditor.php' method='post' enctype='multipart/form-data'>
    <div class='container'>
    <h1 class='header center blue-text text-lighten-2'>Editing Profile</h1>
    <div class='row'>
      <div class='col s2'>
        &nbsp
      </div>
      <div class='col s8 signin'>
        <label for='bio'><b>Enter New Bio</b></label>
        <textarea maxlength='120' rows = '5' cols = '60' name = 'bio' required></textarea>
      </div>
      <div class='col s2'>
        &nbsp
      </div>
    </div>

    <div class='row'>
      <div class='col s2'>
        &nbsp
      </div>
      <div class='col s6 file-field input-field'>
        <div class='btn waves-effect waves-light blue lighten-1'>
          <span>Profile Picture</span>
          <input type='file' name='uploadimg' accept='image/*' required>
        </div>
        <div class='file-path-wrapper'>
          <input class='file-path validate' type='text'>
        </div>
      </div>
      <div class='col s2'>
        <button class='btn waves-effect waves-light blue lighten-1' type='submit' name='submit'>Submit</button>
      </div>
    </div>

    </div>
    </form>";

   ?>

</body>

</html>

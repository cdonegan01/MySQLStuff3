<?php

    session_start();

    if(isset($_SESSION['myUserID']))
    {

    } else {
      header('location: index.php');
    }

    include("conn.php");

    $uploads_name = 'http://cdonegan01.lampt.eeecs.qub.ac.uk/projectstuff/backloggr/img/profilePictures/';
    $uploads_dir = 'img/profilePictures/';

    $userId = $_SESSION['myUserID'];

    $biodata = $conn->real_escape_string($_POST["bio"]);

    $filename = $_FILES['uploadimg']['name'];

    $filetmp = $_FILES['uploadimg']['tmp_name'];

    move_uploaded_file($filetmp, $uploads_dir.$filename);

      $insertsql = "UPDATE LB_Users SET Bio = '$biodata', Avatar = '$uploads_name$filename' WHERE User_ID = '$userId'";
      $result = $conn->query($insertsql);


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Page Title -->
  <title>BackLoggr</title>

	<!-- Compiled and minified CSS -->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link href="style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

	<!-- Compiled and minified JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

	<script>
	   $(function(){
      $(".dropdown-trigger").dropdown();
			$('.tooltipped').tooltip();
	   });
	</script>

<body>
  <div class="navbar-fixed">
    <nav role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="index.php" class="brand-logo left"><i class="material-icons">videogame_asset</i>BackLoggr</a>
       <ul id="nav-mobile" class="right">
         <?php
         if(isset($_SESSION['myusername']))
         {
           echo "<li><a href='user.php'>My Profile</a></li>";
         } else {
         }
          ?>
        <li><form>
       </form></li>
      </ul>
    </div>
  </nav>
 </div>

  <?php
  if(!$result){
    echo $conn->error;
  }else{
    echo "<div id='index-banner' class='container'>
      <div class='section no-pad-bot'>
        <div class='container'>
          <h1 class='header center blue-text text-lighten-2'>Your details have been edited successfully!</h1>
          <div class='row center'>
            <div class='row center'>
              <a href='user.php' class='btn-large waves-effect waves-light blue lighten-1'>Go to My Profile</a>
            </div>
          </div>
        </div>
      </div>
    </div>";
  }

   ?>

</body>

</html>

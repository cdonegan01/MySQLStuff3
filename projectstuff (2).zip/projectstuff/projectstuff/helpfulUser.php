<?php
include 'conn.php';
include 'functions.php';

//Retrieving variables from post

$likingUser = $_POST["first"];
$likedUser = $_POST["second"];

//Converting String Vars to Integers before insertion

$likingUser1 = $likingUser;
var_dump($likingUser1); 
$likingUser1= $likingUser1 +0; 
var_dump($likingUser1); 

$likedUser1 = $likedUser;
var_dump($likedUser1); 
$likedUser1= $likedUser1 +0; 
var_dump($likedUser1); 

		//Inserting data into the HelpfulUser table to facilitate interaction

		$insertQuery = "INSERT INTO LB_HelpfulUser(Liking_User, Liked_User) VALUES ($likingUser1,$likedUser1)";
		$result = $conn->query($insertQuery);
?>

<?php
include 'conn.php';
include 'functions.php';

	//Retrieving variables from post

	$liker = $_POST["first"];
	$reviewId = $_POST["second"];
	
	//Converting String Vars to Integers before insertion

	$liker1 = $liker;
  var_dump($liker1); 
  $liker1= $liker1 +0; 
  var_dump($liker1); 

  $reviewId1 = $reviewId;
  var_dump($reviewId1); /)
  $reviewId1= $reviewId1 +0; 
  var_dump($reviewId1); 
  
  //Inserting data into the HelpfulUser table to facilitate interaction

	$insertQuery = "INSERT INTO LB_ReviewLikes(Liker, Review) VALUES ($liker1,$reviewId1)";
	$result = $conn->query($insertQuery);
?>

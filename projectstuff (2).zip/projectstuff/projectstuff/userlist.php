<?php

//Retrieves user data from database 

  include("conn.php");
  $read = "SELECT * FROM LB_Users ORDER BY id DESC";
  $result = $conn->query($read);

  $dbdata = array();

//Fetch into associative array
  while ($row = $result->fetch_assoc())  {
	   $dbdata[]=$row;
  }

//Print array in JSON format
echo json_encode($dbdata);

?>

<?php
$lengthOfSalt = 32;
/**
* Queries the database and checks whether the user already exists
*
* @param $username
*
* @return
*/
function userExists($username){
	$query = "SELECT Username FROM LB_Users WHERE username = ?";
	global $conn;
	if($stmt = $conn->prepare($query)){
		$stmt->bind_param("s",$username);
		$stmt->execute();
		$stmt->store_result();
		$stmt->fetch();
		if($stmt->num_rows == 1){
			$stmt->close();
			return true;
		}
		$stmt->close();
	}

	return false;
}

/**
* Creates a unique Salt for hashing the password
*
* @return
*/
function getSalt(){
	global $lengthOfSalt;
	return bin2hex(openssl_random_pseudo_bytes($lengthOfSalt));
}

/**
* Creates password hash using the Salt and the password
*
* @param $password
* @param $salt
*
* @return
*/
function concatPasswordWithSalt($password,$salt){
	global $lengthOfSalt;
	if($lengthOfSalt % 2 == 0){
		$mid = $lengthOfSalt / 2;
	}
	else{
		$mid = ($lengthOfSalt - 1) / 2;
	}

	return
	substr($salt,0,$mid - 1).$password.substr($salt,$mid,$lengthOfSalt - 1);

}
?>

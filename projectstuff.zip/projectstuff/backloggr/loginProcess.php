<?php

  session_start();

  include 'conn.php';
  include 'functions.php';

  $username = $_POST['username'];
  $password = $_POST['password'];

  $query    = "SELECT user_id,Bio,Avatar,Followers,Type,password_hash, salt FROM LB_Users WHERE Username = ?";

  	if($stmt = $conn->prepare($query)){
  		$stmt->bind_param("s",$username);
  		$stmt->execute();
  		$stmt->bind_result($userId,$bio,$avatar,$followers,$type,$passwordHashDB,$salt);
  		if($stmt->fetch()){
  			//Validate the password
  			if(password_verify(concatPasswordWithSalt($password,$salt),$passwordHashDB)){
          $_SESSION['myusername'] = $username;

          header('location: user.php');
  			}
  			else{
  				$_SESSION['loginError'] = "Invalid username and password combination";
  			}
    }else{
    $_SESSION['loginError'] = "That Username/Password combination is not recognized.";
    header('location: index.php');
  }
}

?>

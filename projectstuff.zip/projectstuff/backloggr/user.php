<?php

  include("conn.php");

  session_start();

  if(isset($_SESSION['myusername']))
  {

  } else {
    header('location: index.php');
  }

  $username = $_SESSION['myusername'];

  $read = "SELECT * FROM LB_Users WHERE Username = '$username'";
  $result = $conn->query($read);


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Page Title -->
  <title>ElmTree</title>

	<!-- Compiled and minified CSS -->
	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link href="style.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Noto+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

	<!-- Compiled and minified JavaScript -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

	<script>
	   $(function(){
      $(".dropdown-trigger").dropdown();
			$('.tooltipped').tooltip();
	   });
	</script>

<body>
    <div class="navbar-fixed">
      <nav role="navigation">
      <div class="nav-wrapper container">
        <a id="logo-container" href="index.php" class="brand-logo left"><i class="material-icons">videogame_asset</i>BackLoggr</a>
         <ul id="nav-mobile" class="right">
           <?php
           if(isset($_SESSION['myusername']))
           {
             echo "<li><a href='user.php'>My Profile</a></li>";
           } else {
           }
            ?>
          <li><form>
         </form></li>
        </ul>
      </div>
    </nav>
   </div>

  <div class="container">
    <div class="row">
      <?php

		    while($row = $result->fetch_assoc()){

             $userId = $row['user_id'];
			       $name = $row['Username'];
             $bio = $row['Bio'];
             $ProfilePic = $row['Avatar'];
             $followers = $row['Followers'];

             $_SESSION['myUserID'] = $userId;
			          echo "<div class='col s12'>
                      <div class='card-panel grey lighten-5 z-depth-1'>
                      <div class='row valign-wrapper'>
                      <div class='col s2'>
                      <img src='$ProfilePic' alt='' class='circle responsive-img'>
                      </div>
                      <div class='col s10 signin'>
                      <span class='black-text'>
                        <h1>$name</h1>
                        <p class='title'>$bio</p>
                        <p>Followers: $followers</p>
                        </span>
                        </div>
                          </div>
                      </div>
                      </div>";

		   }
	?>
  </div>
  </div>

  <div class="container">


    <div id="buttonHolder" class = "col s12 row card-panel grey lighten-5 z-depth-1">
      <div id="editProfileButton" class="col s4 signin">
        <a href='userEdit.php' class='btn-large waves-effect waves-light blue lighten-1'>Edit Profile</a>
      </div>
      <div id="gameListButton" class="col s4 signin">
        <a href='gamelist.php' class='btn-large waves-effect waves-light blue lighten-1'>New Review</a>
      </div>
      <div id="signoutButton" class="col s4 signin">
        <a href='signout.php' class='btn-large waves-effect waves-light blue lighten-1'>Sign Out</a>
      </div>
    </div>


    <!--
    <div class="input-field">
      <input id="search" type="search" required>
      <label class="label-icon" for="search"><i class="material-icons">search</i></label>
      <i class="material-icons">close</i>
    </div>
  -->

<!--
  <form action='search.php' method='post' enctype='multipart/form-data'>
  <div id=searchBarUser class='container'>
  <div class='row'>
    <div class='col s10 signin'>
      <label for='query'><b>Search for a game to review.</b></label>
      <input type='text' placeholder='Search for a Game' name='query' required>
    </div>
    <div class='col s2'>
      <button class='btn waves-effect waves-light blue lighten-1' type='submit' name='submit'>Submit</button>
    </div>
  </div>
</div>
</form>
  -->

</body>

</html>

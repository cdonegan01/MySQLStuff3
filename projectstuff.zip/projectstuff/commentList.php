<?php

require "conn.php";

$mysqli1 = "SELECT LB_Users.Username, LB_Comments.Comment, LB_Comments.id, LB_Comments.User, LB_Users.user_id, LB_Users.Avatar, LB_Comments.Review,
            LB_Reviews.Game, LB_Reviews.Author FROM LB_Comments
            INNER Join
            LB_Users
            ON
            LB_Comments.User = LB_Users.user_id
            INNER Join
            LB_Reviews
            ON
            LB_Reviews.Review_id = LB_Comments.Review";

$result = mysqli_query($conn, $mysqli1);

//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ($row = $result->fetch_assoc())  {
	   $dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);

?>

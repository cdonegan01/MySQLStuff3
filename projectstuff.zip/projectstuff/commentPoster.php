<?php
$response = array();
include 'conn.php';
include 'functions.php';

//Get the input request parameters
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array

//Check for Mandatory parameters
if(isset($input['Comment']) && isset($input['User']) && isset($input['Review'])){
	$comment = $input['Comment'];
	$userId = $input['User'];
	$review = $input['Review'];

	$userId1 = $userId;
	$userId1= $userId1 +0;

	$review1 = $review;
	$review1= $review1 +0;

		//Query to register new user
		$insertQuery  = "INSERT INTO LB_Comments(Comment, User, Review) VALUES (?,?,?)";
		if($stmt = $conn->prepare($insertQuery)){
			$stmt->bind_param("sii",$comment,$userId1,$review1);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "User created";
			$stmt->close();
		}
	}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}
echo json_encode($response);
?>

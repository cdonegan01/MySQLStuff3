<?php
include "conn.php";

$authorID = $_POST["author"];
$comment = $_POST["comment"];
$reviewID = $_POST["review"];

		$insertQuery = "INSERT INTO LB_Users(Comment, User, Review) VALUES ($authorID,$comment,$reviewID)";
		$result = $conn->query($insertsql);
?>

<?php
        $host = "localhost";
        $user = "root";
        $pw = "";
        $db = "cdonegan01";

        $conn = new mysqli($host, $user, $pw, $db);

        if($conn->connect_error) {
          echo $conn->connect_error;
        }
?>

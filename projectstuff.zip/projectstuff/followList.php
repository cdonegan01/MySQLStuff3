<?php

require "conn.php";

$mysqli1 = "SELECT * FROM LB_UserFollowers";

$result = mysqli_query($conn, $mysqli1);

//Initialize array variable
  $dbdata = array();

//Fetch into associative array
  while ($row = $result->fetch_assoc())  {
	   $dbdata[]=$row;
  }

//Print array in JSON format
 echo json_encode($dbdata);

?>

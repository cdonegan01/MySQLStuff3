<?php
include 'conn.php';
include 'functions.php';

$likingUser = $_POST["first"];
$likedUser = $_POST["second"];

$likingUser1 = $likingUser;
var_dump($likingUser1); // string '13' (length=2)
$likingUser1= $likingUser1 +0; // or $myVar+= 0
var_dump($likingUser1); // int 13

$likedUser1 = $likedUser;
var_dump($likedUser1); // string '13' (length=2)
$likedUser1= $likedUser1 +0; // or $myVar+= 0
var_dump($likedUser1); // int 13

		$insertQuery = "INSERT INTO LB_HelpfulUser(Liking_User, Liked_User) VALUES ($likingUser1,$likedUser1)";
		$result = $conn->query($insertQuery);
?>

<?php
require "conn.php";
$user_name = $_POST["username"];
$user_pass = $_POST["password"];
$mysqli1 = "SELECT * FROM LB_Users wHERE Username LIKE '$user_name' AND Password LIKE '$user_pass'";
$result = mysqli_query($conn, $mysqli1);
if (mysqli_num_rows($result) > 0) {
  echo $mysqli1;
} else {
  echo "";

}

 ?>

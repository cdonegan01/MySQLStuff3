<?php
include "conn.php";
include 'functions.php';

$username = $_POST["username"];
$password = $_POST["password"];

	$query = "SELECT * FROM LB_Users WHERE Username = '$username'";

	$result = $conn->query($query);

	while($row = $result->fetch_assoc()){
			 $salt = $row['salt'];
			 $passwordHashDB = $row['password_hash'];
	}
			if(password_verify(concatPasswordWithSalt($password,$salt),$passwordHashDB)){
			}
			else{
				echo "Invalid username and password combination";
			}
?>

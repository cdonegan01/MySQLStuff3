<?php

require "conn.php";
require "functions.php";
$user_name = $_POST["username"];
$user_pass = $_POST["password"];
$user_mail = $_POST["email"];

$checkuser = "SELECT * FROM LB_Users WHERE Username='$user_name'";

$result = $conn->query($checkuser);

$num = $result -> num_rows;

if($num < 1 ) {

  //Get a unique Salt
  $salt = getSalt();

  //Generate a unique password Hash
  $passwordHash = password_hash(concatPasswordWithSalt($user_pass,$salt),PASSWORD_DEFAULT);

  $insertsql = "INSERT INTO LB_Users (Email, Username, Type, salt, password_hash) VALUES ('$user_mail', '$user_name', '1', '$salt', '$passwordHash')";

  $result = $conn->query($insertsql);

  echo "Insert successful";

}else{
  echo "Apologies, that username has been taken. Please choose another.";
}

 ?>

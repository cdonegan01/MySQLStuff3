<?php
include "conn.php";
include 'functions.php';

$username = $_POST["username"];
$password = $_POST["password"];
$email = $_POST["email"];

		//Get a unique Salt
		$salt = getSalt();

		//Generate a unique password Hash
		$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);

		//Query to register new user
		$insertQuery = "INSERT INTO LB_Users(Username, Email, Type, password_hash, salt) VALUES ($username,$email,1,$passwordHash,$salt)";
		$result = $conn->query($insertQuery);
?>

<?php
include 'conn.php';
include 'functions.php';

	$liker = $_POST["first"];
	$reviewId = $_POST["second"];

	$liker1 = $liker;
  var_dump($liker1); // string '13' (length=2)
  $liker1= $liker1 +0; // or $myVar+= 0
  var_dump($liker1); // int 13

  $reviewId1 = $reviewId;
  var_dump($reviewId1); // string '13' (length=2)
  $reviewId1= $reviewId1 +0; // or $myVar+= 0
  var_dump($reviewId1); // int 13

	$insertQuery = "INSERT INTO LB_ReviewLikes(Liker, Review) VALUES ($liker1,$reviewId1)";
	$result = $conn->query($insertQuery);
?>

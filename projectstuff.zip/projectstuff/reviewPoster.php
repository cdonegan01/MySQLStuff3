<?php
$response = array();
include 'conn.php';
include 'functions.php';

//Get the input request parameters
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array

//Check for Mandatory parameters
if(isset($input['Author']) && isset($input['Review']) && isset($input['Game']) && isset($input['Rating']) && isset($input['Heading'])){
	$authorID = $input['Author'];
	$review = $input['Review'];
	$gameID = $input['Game'];
	$rating = $input['Rating'];
	$heading = $input['Heading'];

	$authorID1 = $authorID;
	$authorID1= $authorID1 +0; // or $myVar+= 0

	$gameID1 = $gameID;
	$gameID1= $gameID1 +0; // or $myVar+= 0

	$rating1 = $rating;
	$rating1= $rating1 +0; // or $myVar+= 0

		//Query to register new user
		$insertQuery  = "INSERT INTO LB_Reviews(Game, Author, Review, Rating, Heading) VALUES (?,?,?,?,?)";
		if($stmt = $conn->prepare($insertQuery)){
			$stmt->bind_param("iisis",$gameID1,$authorID1,$review,$rating1,$heading);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "User created";
			$stmt->close();
			/*
			$GetAverage = "SELECT AVG(Rating) FROM LB_Reviews WHERE Game = $gameID1";
			$result = mysqli_query($conn, $GetAverage);
			while ($row = $result->fetch_assoc())  {
				   $retrievedAverage=$row;
			  }
			$retrievedAverage=$retrievedAverage +0;
			$SetAverage = "UPDATE LB_Games SET average_rating = $retrievedAverage WHERE id = $gameID1";
			$result = $conn->query($SetAverage);
			*/
		}
	}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}
echo json_encode($response);
?>

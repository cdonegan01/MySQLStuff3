<?php
include 'conn.php';
include 'functions.php';

	$authorID = $_POST["first"];
	$review = $_POST["second"];
	$gameID = $_POST["third"];
	$rating = $_POST["fourth"];
	$heading = $_POST["fifth"];
	$likes = 0;

	$authorID1 = $authorID;
	var_dump($authorID1); // string '13' (length=2)
	$authorID1= $authorID1 +0; // or $myVar+= 0
	var_dump($authorID1); // int 13

	$gameID1 = $gameID;
	$gameID1= $gameID1 +0; // or $myVar+= 0
	var_dump($gameID1); // int 13

	$rating1 = $rating;
	$rating1= $rating1 +0; // or $myVar+= 0
	var_dump($rating1); // int 13

	$insertQuery = "INSERT INTO LB_Reviews(Game, Author, Review, Rating, Heading, Likes) VALUES ($gameID1,$authorID1,$review,$rating,$heading, $likes)";
	$result = $conn->query($insertQuery);
?>

<?php
$response = array();
include 'conn.php';
include 'functions.php';

//Get the input request parameters
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE); //convert JSON into array

//Check for Mandatory parameters
if(isset($input['followingUser']) && isset($input['followedUser']){
	$followingUser = $input['followingUser'];
	$followedUser = $input['followedUser'];

  $followingUser1 = $followingUser;
  var_dump($followingUser1); // string '13' (length=2)
  $followingUser1= $followingUser1 +0; // or $myVar+= 0
  var_dump($followingUser1); // int 13

  $followedUser1 = $followedUser;
  var_dump($followedUser1); // string '13' (length=2)
  $followedUser1= $followedUser1 +0; // or $myVar+= 0
  var_dump($followedUser1); // int 13

	$insertQuery  = "INSERT INTO LB_UserFollowers(User, FollowedUser) VALUES (?,?)";
	if($stmt = $conn->prepare($insertQuery)){
			$stmt->bind_param("ii",$followingUser1,$followedUser1);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "You are now following this user!";
			$stmt->close();
	}
	} else{
		$response["status"] = 1;
		$response["message"] = "Error!";
	}
echo json_encode($response);
?>

<?php
include 'conn.php';
include 'functions.php';

	$followingUser = $_POST["first"];
	$followedUser = $_POST["second"];

  $followingUser1 = $followingUser;
  var_dump($followingUser1); // string '13' (length=2)
  $followingUser1= $followingUser1 +0; // or $myVar+= 0
  var_dump($followingUser1); // int 13

  $followedUser1 = $followedUser;
  var_dump($followedUser1); // string '13' (length=2)
  $followedUser1= $followedUser1 +0; // or $myVar+= 0
  var_dump($followedUser1); // int 13

	$insertQuery = "INSERT INTO LB_UserFollowers(User, FollowedUser) VALUES ($followingUser1,$followedUser1)";
	$result = $conn->query($insertQuery);
?>
